package com.example.studente.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    private SeekBar seekBar;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iniz();
    }

    private void iniz(){
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        textView = (TextView) findViewById(R.id.textView);
        textView.setText("30 sec");
        seekBar.setProgress(30);
        seekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            int progress = 30;
            @Override
            public void onProgressChanged(SeekBar seekBar,int progresValue, boolean fromUser) {
                progress = progresValue;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do something here,

                //if you want to do anything at the start of
                // touching the seekbar
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int a = progress/60;
                int b = progress%60;
                if(a<1){
                    textView.setText(b + " sec");
                }else{
                    textView.setText(a+"min e "+b + " sec");
                }
            }
        });
    }
    }

